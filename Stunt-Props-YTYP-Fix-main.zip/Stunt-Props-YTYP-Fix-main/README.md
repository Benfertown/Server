# GTA 5 Stunt Prop YTYP Fix
 Fixed YTYP files for stunt props
 
 Fixed models to enable working LOD - 🚧WIP🚧
 
 Add the folder as a resource in FiveM and it will fix the props not showing up.
 
 It's basically magic! 🧙
